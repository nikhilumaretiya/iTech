<?php
require_once "config.php";

$fname = $lname  = $mobile = $email = $experience = $skills = "";
$fname_err = $lname_err = $mobile_err = $email_err = $experience_err = $skills_err = "";

if ($_SERVER['REQUEST_METHOD'] == "POST"){

    if(empty(trim($_POST["fname"]))){
        $fname_err = "First cannot be blank";
    }
    if(empty(trim($_POST["lname"]))){
        $lname_err = "Last cannot be blank";
    }
    if(empty(trim($_POST["mobile"]))){
        $mobile_err = "Mobile No. cannot be blank";
    }
    if(empty(trim($_POST["email"]))){
        $email_err = "Email cannot be blank";
    }
    if(empty(trim($_POST["experience"]))){
        $experience_err = "Experience cannot be blank";
    }
 
    
    else{
        $sql = "INSERT INTO emp_details (fname, laname, mobile, email) VALUES (?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        if ($stmt)
        {
            mysqli_stmt_bind_param($stmt, "ss", $param_fname, $param_lname);
            $param_fname = $fname;
            $param_lname = $lname;
            if (mysqli_stmt_execute($stmt))
            {
                header("location: login.php");
            }
            else{
                echo "Something went wrong... cannot redirect!";
         }
        }
        mysqli_stmt_close($stmt);
    }
    
    
mysqli_close($conn);
}


?>
<!doctype html>
<html lang="en">
  <head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.8.1/css/bootstrap-select.css">
    <title>Employee Details</title>
  </head>
  <body>


  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="register.php">Employee Details</a>
</nav>

<div class="container mt-4">
<h3>Please Register Here:</h3>
<hr>
<form action="" method="post" class="details">
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputfname">First Name</label>
            <input type="text" class="form-control" name ="fname" id="fname" placeholder="Enter First Name" required>
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputlname">Last Name</label>
            <input type="text" class="form-control" name ="lname" id="lname" placeholder="Enter Last Name" required>
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="phone">Mobile No.</label>
            <input type="tel" class="form-control" name ="mobile" id="phone" placeholder="Enter Mobile No." required>
        </div>
    </div>
  <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputEmail4">Email</label>
            <input type="text" class="form-control" name="email" id="inputEmail4" placeholder="Enter Email" required>
        </div>
  </div>
  <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputage">Age</label>
            <input type="number" class="form-control" name="age" id="inputEmail4" placeholder="Enter Age" required>
        </div>
  </div>
  <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputexp">Experience</label>
            <input type="number" class="form-control" name="experience" id="experience" placeholder="Enter Experience" required>
        </div>
  </div>
  <div class="form-group col-md-10">
  <label for="inputState"><strong>Please Attach your CV Here</strong></label></br>
    <input type="file" id="resume" accept=".pdf/*,doc/*" />

  </div>
  <div class="form-group col-md-8">
            <label for="inputState">Skills</label>
            <select class="selectpicker" multiple data-live-search="true">
                <option>Php</option>
                <option>Flutter</option>
                <option>ASP.NET </option>
                <option>Full Stack Developer</option>
                <option>Frontend Developer</option>
                <option>other</option>
            </select>
        </div>
    <div class="form-group col-md-8">
    <button type="submit" class="btn btn-primary" onclick="submit()">Apply Now</button>
    
    </div>        
    <script type="text/javascript">

        function submit() {

            var detail=$("#detail").val();
            $.ajax({
            type: "POST",
            url: "register.php",
            data: {detail:detail},
            dataType: "JSON",
            success: function(data) {
            $("#message").html(data);
            $("p").addClass("alert alert-success");
            },
            error: function(err) {
                alert(err);
            }
        });

}

</script>
</form>
</div>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.8.1/js/bootstrap-select.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
  </body>
</html>
